var _sentryDebugIds,_sentryDebugIdIdentifier;void 0===_sentryDebugIds&&(_sentryDebugIds={});try{var stack=(new Error).stack;stack&&(_sentryDebugIds[stack]="4398aa4d-bdec-466c-8a33-544a5a0dd155",_sentryDebugIdIdentifier="sentry-dbid-4398aa4d-bdec-466c-8a33-544a5a0dd155")}catch(e){}
var SENTRY_RELEASE;SENTRY_RELEASE={name: "Empreinte", version: "27.1.1"};
__d(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),Object.keys(r(d[0])).forEach(function(t){'default'===t||Object.prototype.hasOwnProperty.call(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:function(){return r(d[0])[t]}})})},12035,[12039]);
__d(function(g,r,i,a,m,_e,d){"use strict";Object.defineProperty(_e,'__esModule',{value:!0}),Object.defineProperty(_e,"getAnalytics",{enumerable:!0,get:function(){return Z}}),Object.defineProperty(_e,"getGoogleAnalyticsClientId",{enumerable:!0,get:function(){return ae}}),Object.defineProperty(_e,"initializeAnalytics",{enumerable:!0,get:function(){return ee}}),Object.defineProperty(_e,"isSupported",{enumerable:!0,get:function(){return te}}),Object.defineProperty(_e,"logEvent",{enumerable:!0,get:function(){return ce}}),Object.defineProperty(_e,"setAnalyticsCollectionEnabled",{enumerable:!0,get:function(){return oe}}),Object.defineProperty(_e,"setConsent",{enumerable:!0,get:function(){return le}}),Object.defineProperty(_e,"setCurrentScreen",{enumerable:!0,get:function(){return ne}}),Object.defineProperty(_e,"setDefaultEventParameters",{enumerable:!0,get:function(){return se}}),Object.defineProperty(_e,"setUserId",{enumerable:!0,get:function(){return ie}}),Object.defineProperty(_e,"setUserProperties",{enumerable:!0,get:function(){return re}}),Object.defineProperty(_e,"settings",{enumerable:!0,get:function(){return Q}}),r(d[0]);
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
const e='analytics',t='https://www.googletagmanager.com/gtag/js',n=new(r(d[1]).Logger)('@firebase/analytics'),o={"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-initialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":'Firebase Analytics Interop Component failed to instantiate: {$reason}',"invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":'Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}',"no-api-key":"The \"apiKey\" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.","no-app-id":"The \"appId\" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.","no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":'Trusted Types detected an invalid gtag resource: {$gtagURL}.'},s=new(r(d[2]).ErrorFactory)('analytics','Analytics',o);
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
function c(e){if(!e.startsWith(t)){const t=s.create("invalid-gtag-resource",{gtagURL:e});return n.warn(t.message),''}return e}function l(e){return Promise.all(e.map(e=>e.catch(e=>e)))}function u(e,t){let n;return window.trustedTypes&&(n=window.trustedTypes.createPolicy(e,t)),n}function p(e,n){const o=u('firebase-js-sdk-policy',{createScriptURL:c}),s=document.createElement('script'),l=`${t}?l=${e}&id=${n}`;s.src=o?o?.createScriptURL(l):l,s.async=!0,document.head.appendChild(s)}function f(e){let t=[];return Array.isArray(window[e])?t=window[e]:window[e]=t,t}async function h(e,t,o,s,c,u){const p=s[c];try{if(p)await t[p];else{const e=(await l(o)).find(e=>e.measurementId===c);e&&await t[e.appId]}}catch(e){n.error(e)}e("config",c,u)}async function y(e,t,o,s,c){try{let n=[];if(c&&c.send_to){let e=c.send_to;Array.isArray(e)||(e=[e]);const s=await l(o);for(const o of e){const e=s.find(e=>e.measurementId===o),c=e&&t[e.appId];if(!c){n=[];break}n.push(c)}}0===n.length&&(n=Object.values(t)),await Promise.all(n),e("event",s,c||{})}catch(e){n.error(e)}}function w(e,t,o,s){return async function(c,...l){try{if("event"===c){const[n,s]=l;await y(e,t,o,n,s)}else if("config"===c){const[n,c]=l;await h(e,t,o,s,n,c)}else if("consent"===c){const[t,n]=l;e("consent",t,n)}else if("get"===c){const[t,n,o]=l;e("get",t,n,o)}else if("set"===c){const[t]=l;e("set",t)}else e(c,...l)}catch(e){n.error(e)}}}function b(e,t,n,o,s){let c=function(...e){window[o].push(arguments)};return window[s]&&'function'==typeof window[s]&&(c=window[s]),window[s]=w(c,e,t,n),{gtagCore:c,wrappedGtag:window[s]}}function I(e){const n=window.document.getElementsByTagName('script');for(const o of Object.values(n))if(o.src&&o.src.includes(t)&&o.src.includes(e))return o;return null}
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */const v=new class{constructor(e={},t=1e3){this.throttleMetadata=e,this.intervalMillis=t}getThrottleMetadata(e){return this.throttleMetadata[e]}setThrottleMetadata(e,t){this.throttleMetadata[e]=t}deleteThrottleMetadata(e){delete this.throttleMetadata[e]}};function P(e){return new Headers({Accept:'application/json','x-goog-api-key':e})}async function M(e){const{appId:t,apiKey:n}=e,o={method:'GET',headers:P(n)},c="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig".replace('{app-id}',t),l=await fetch(c,o);if(200!==l.status&&304!==l.status){let e='';try{const t=await l.json();t.error?.message&&(e=t.error.message)}catch(e){}throw s.create("config-fetch-failed",{httpStatus:l.status,responseMessage:e})}return l.json()}async function T(e,t=v,n){const{appId:o,apiKey:c,measurementId:l}=e.options;if(!o)throw s.create("no-app-id");if(!c){if(l)return{measurementId:l,appId:o};throw s.create("no-api-key")}const u=t.getThrottleMetadata(o)||{backoffCount:0,throttleEndTimeMillis:Date.now()},p=new F;return setTimeout(async()=>{p.abort()},void 0!==n?n:6e4),A({appId:o,apiKey:c,measurementId:l},u,p,t)}async function A(e,{throttleEndTimeMillis:t,backoffCount:o},s,c=v){const{appId:l,measurementId:u}=e;try{await D(s,t)}catch(e){if(u)return n.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${u} provided in the "measurementId" field in the local Firebase config. [${e?.message}]`),{appId:l,measurementId:u};throw e}try{const t=await M(e);return c.deleteThrottleMetadata(l),t}catch(t){const p=t;if(!j(p)){if(c.deleteThrottleMetadata(l),u)return n.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${u} provided in the "measurementId" field in the local Firebase config. [${p?.message}]`),{appId:l,measurementId:u};throw t}const f=503===Number(p?.customData?.httpStatus)?(0,r(d[2]).calculateBackoffMillis)(o,c.intervalMillis,30):(0,r(d[2]).calculateBackoffMillis)(o,c.intervalMillis),h={throttleEndTimeMillis:Date.now()+f,backoffCount:o+1};return c.setThrottleMetadata(l,h),n.debug(`Calling attemptFetch again in ${f} millis`),A(e,h,s,c)}}function D(e,t){return new Promise((n,o)=>{const c=Math.max(t-Date.now(),0),l=setTimeout(n,c);e.addEventListener(()=>{clearTimeout(l),o(s.create("fetch-throttle",{throttleEndTimeMillis:t}))})})}function j(e){if(!(e instanceof r(d[2]).FirebaseError&&e.customData))return!1;const t=Number(e.customData.httpStatus);return 429===t||500===t||503===t||504===t}class F{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */let E,$;async function x(e,t,n,o,s){if(s&&s.global)e("event",n,o);else{const s=await t;e("event",n,Object.assign({},o,{send_to:s}))}}async function C(e,t,n,o){if(o&&o.global)return e("set",{screen_name:n}),Promise.resolve();e("config",await t,{update:!0,screen_name:n})}async function O(e,t,n,o){if(o&&o.global)return e("set",{user_id:n}),Promise.resolve();e("config",await t,{update:!0,user_id:n})}async function _(e,t,n,o){if(o&&o.global){const t={};for(const e of Object.keys(n))t[`user_properties.${e}`]=n[e];return e("set",t),Promise.resolve()}e("config",await t,{update:!0,user_properties:n})}async function k(e,t){const n=await t;return new Promise((t,o)=>{e("get",n,'client_id',e=>{e||o(s.create("no-client-id")),t(e)})})}async function z(e,t){const n=await e;window[`ga-disable-${n}`]=!t}function B(e){$=e}function L(e){E=e}
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function S(){if(!(0,r(d[2]).isIndexedDBAvailable)())return n.warn(s.create("indexeddb-unavailable",{errorInfo:'IndexedDB is not available in this environment.'}).message),!1;try{await(0,r(d[2]).validateIndexedDBOpenable)()}catch(e){return n.warn(s.create("indexeddb-unavailable",{errorInfo:e?.toString()}).message),!1}return!0}async function U(e,t,o,s,c,l,u){const f=T(e);f.then(t=>{o[t.measurementId]=t.appId,e.options.measurementId&&t.measurementId!==e.options.measurementId&&n.warn(`The measurement ID in the local Firebase config (${e.options.measurementId}) does not match the measurement ID fetched from the server (${t.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(e=>n.error(e)),t.push(f);const h=S().then(e=>e?s.getId():void 0),[y,w]=await Promise.all([f,h]);I(l)||p(l,y.measurementId),$&&(c("consent",'default',$),B(void 0)),c('js',new Date);const b=u?.config??{};return b.origin='firebase',b.update=!0,null!=w&&(b.firebase_id=w),c("config",y.measurementId,b),E&&(c("set",E),L(void 0)),y.measurementId}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */class N{constructor(e){this.app=e}_delete(){return delete K[this.app.options.appId],Promise.resolve()}}let K={},q=[];const R={};let G,V,W='dataLayer',H='gtag',J=!1;function Q(e){if(J)throw s.create("already-initialized");e.dataLayerName&&(W=e.dataLayerName),e.gtagName&&(H=e.gtagName)}function X(){const e=[];if((0,r(d[2]).isBrowserExtension)()&&e.push('This is a browser extension environment.'),(0,r(d[2]).areCookiesEnabled)()||e.push('Cookies are not available.'),e.length>0){const t=e.map((e,t)=>`(${t+1}) ${e}`).join(' '),o=s.create("invalid-analytics-context",{errorInfo:t});n.warn(o.message)}}function Y(e,t,o){X();const c=e.options.appId;if(!c)throw s.create("no-app-id");if(!e.options.apiKey){if(!e.options.measurementId)throw s.create("no-api-key");n.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${e.options.measurementId} provided in the "measurementId" field in the local Firebase config.`)}if(null!=K[c])throw s.create("already-exists",{id:c});if(!J){f(W);const{wrappedGtag:e,gtagCore:t}=b(K,q,R,W,H);V=e,G=t,J=!0}K[c]=U(e,q,R,t,G,W,o);return new N(e)}function Z(t=(0,r(d[3]).getApp)()){t=(0,r(d[2]).getModularInstance)(t);const n=(0,r(d[3])._getProvider)(t,e);return n.isInitialized()?n.getImmediate():ee(t)}function ee(t,n={}){const o=(0,r(d[3])._getProvider)(t,e);if(o.isInitialized()){const e=o.getImmediate();if((0,r(d[2]).deepEqual)(n,o.getOptions()))return e;throw s.create("already-initialized")}return o.initialize({options:n})}async function te(){if((0,r(d[2]).isBrowserExtension)())return!1;if(!(0,r(d[2]).areCookiesEnabled)())return!1;if(!(0,r(d[2]).isIndexedDBAvailable)())return!1;try{return await(0,r(d[2]).validateIndexedDBOpenable)()}catch(e){return!1}}function ne(e,t,o){e=(0,r(d[2]).getModularInstance)(e),C(V,K[e.app.options.appId],t,o).catch(e=>n.error(e))}async function ae(e){return e=(0,r(d[2]).getModularInstance)(e),k(V,K[e.app.options.appId])}function ie(e,t,o){e=(0,r(d[2]).getModularInstance)(e),O(V,K[e.app.options.appId],t,o).catch(e=>n.error(e))}function re(e,t,o){e=(0,r(d[2]).getModularInstance)(e),_(V,K[e.app.options.appId],t,o).catch(e=>n.error(e))}function oe(e,t){e=(0,r(d[2]).getModularInstance)(e),z(K[e.app.options.appId],t).catch(e=>n.error(e))}function se(e){V?V("set",e):L(e)}function ce(e,t,o,s){e=(0,r(d[2]).getModularInstance)(e),x(V,K[e.app.options.appId],t,o,s).catch(e=>n.error(e))}function le(e){V?V("consent",'update',e):B(e)}const de="@firebase/analytics",ue="0.10.19";(0,r(d[3])._registerComponent)(new(r(d[4]).Component)(e,(e,{options:t})=>Y(e.getProvider('app').getImmediate(),e.getProvider('installations-internal').getImmediate(),t),"PUBLIC")),(0,r(d[3])._registerComponent)(new(r(d[4]).Component)('analytics-internal',function(t){try{const n=t.getProvider(e).getImmediate();return{logEvent:(e,t,o)=>ce(n,e,t,o),setUserProperties:(e,t)=>re(n,e,t)}}catch(e){throw s.create("interop-component-reg-failed",{reason:e})}},"PRIVATE")),(0,r(d[3]).registerVersion)(de,ue),(0,r(d[3]).registerVersion)(de,ue,'esm2020')},12039,[12040,3431,3429,3432,3433]);
__d(function(g,r,i,a,m,_e,d){"use strict";Object.defineProperty(_e,'__esModule',{value:!0}),Object.defineProperty(_e,"deleteInstallations",{enumerable:!0,get:function(){return wt}}),Object.defineProperty(_e,"getId",{enumerable:!0,get:function(){return ft}}),Object.defineProperty(_e,"getInstallations",{enumerable:!0,get:function(){return ht}}),Object.defineProperty(_e,"getToken",{enumerable:!0,get:function(){return pt}}),Object.defineProperty(_e,"onIdChange",{enumerable:!0,get:function(){return mt}});const t="@firebase/installations",e="0.6.19",n=1e4,o=`w:${e}`,s='FIS_v2',u='https://firebaseinstallations.googleapis.com/v1',c=36e5,f={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":'Firebase Installation is not registered.',"installation-not-found":'Firebase Installation not found.',"request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":'Could not process request. Application offline.',"delete-pending-registration":"Can't delete installation while there is a pending registration request."},p=new(r(d[0]).ErrorFactory)('installations','Installations',f);function l(t){return t instanceof r(d[0]).FirebaseError&&t.code.includes("request-failed")}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */function w({projectId:t}){return`${u}/projects/${t}/installations`}function h(t){return{token:t.token,requestStatus:2,expiresIn:(e=t.expiresIn,Number(e.replace('s','000'))),creationTime:Date.now()};var e}async function y(t,e){const n=(await e.json()).error;return p.create("request-failed",{requestName:t,serverCode:n.code,serverMessage:n.message,serverStatus:n.status})}function b({apiKey:t}){return new Headers({'Content-Type':'application/json',Accept:'application/json','x-goog-api-key':t})}function C(t,{refreshToken:e}){const n=b(t);return n.append('Authorization',v(e)),n}async function S(t){const e=await t();return e.status>=500&&e.status<600?t():e}function v(t){return`${s} ${t}`}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function I({appConfig:t,heartbeatServiceProvider:e},{fid:n}){const u=w(t),c=b(t),f=e.getImmediate({optional:!0});if(f){const t=await f.getHeartbeatsHeader();t&&c.append('x-firebase-client',t)}const p={fid:n,authVersion:s,appId:t.appId,sdkVersion:o},l={method:'POST',headers:c,body:JSON.stringify(p)},C=await S(()=>fetch(u,l));if(C.ok){const t=await C.json();return{fid:t.fid||n,registrationStatus:2,refreshToken:t.refreshToken,authToken:h(t.authToken)}}throw await y('Create Installation',C)}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */function T(t){return new Promise(e=>{setTimeout(e,t)})}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
const k=/^[cdef][\w-]{21}$/,P='';function j(){try{const t=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(t),t[0]=112+t[0]%16;const e=q(t);return k.test(e)?e:P}catch{return P}}function q(t){var e;return(e=t,btoa(String.fromCharCode(...e)).replace(/\+/g,'-').replace(/\//g,'_')).substr(0,22)}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */function $(t){return`${t.appName}!${t.appId}`}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */const E=new Map;function O(t,e){const n=$(t);A(n,e),N(n,e)}function D(t,e){V();const n=$(t);let o=E.get(n);o||(o=new Set,E.set(n,o)),o.add(e)}function _(t,e){const n=$(t),o=E.get(n);o&&(o.delete(e),0===o.size&&E.delete(n),x())}function A(t,e){const n=E.get(t);if(n)for(const t of n)t(e)}function N(t,e){const n=V();n&&n.postMessage({key:t,fid:e}),x()}let F=null;function V(){return!F&&'BroadcastChannel'in self&&(F=new BroadcastChannel('[Firebase] FID Change'),F.onmessage=t=>{A(t.data.key,t.data.fid)}),F}function x(){0===E.size&&F&&(F.close(),F=null)}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */const M='firebase-installations-database',H=1,L='firebase-installations-store';let B=null;function K(){return B||(B=(0,r(d[1]).openDB)(M,H,{upgrade:(t,e)=>{if(0===e)t.createObjectStore(L)}})),B}async function z(t,e){const n=$(t),o=(await K()).transaction(L,'readwrite'),s=o.objectStore(L),u=await s.get(n);return await s.put(e,n),await o.done,u&&u.fid===e.fid||O(t,e.fid),e}async function J(t){const e=$(t),n=(await K()).transaction(L,'readwrite');await n.objectStore(L).delete(e),await n.done}async function R(t,e){const n=$(t),o=(await K()).transaction(L,'readwrite'),s=o.objectStore(L),u=await s.get(n),c=e(u);return void 0===c?await s.delete(n):await s.put(c,n),await o.done,!c||u&&u.fid===c.fid||O(t,c.fid),c}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function U(t){let e;const n=await R(t.appConfig,n=>{const o=G(n),s=Q(t,o);return e=s.registrationPromise,s.installationEntry});return n.fid===P?{installationEntry:await e}:{installationEntry:n,registrationPromise:e}}function G(t){return Z(t||{fid:j(),registrationStatus:0})}function Q(t,e){if(0===e.registrationStatus){if(!navigator.onLine){return{installationEntry:e,registrationPromise:Promise.reject(p.create("app-offline"))}}const n={fid:e.fid,registrationStatus:1,registrationTime:Date.now()};return{installationEntry:n,registrationPromise:W(t,n)}}return 1===e.registrationStatus?{installationEntry:e,registrationPromise:X(t)}:{installationEntry:e}}async function W(t,e){try{const n=await I(t,e);return z(t.appConfig,n)}catch(n){throw l(n)&&409===n.customData.serverCode?await J(t.appConfig):await z(t.appConfig,{fid:e.fid,registrationStatus:0}),n}}async function X(t){let e=await Y(t.appConfig);for(;1===e.registrationStatus;)await T(100),e=await Y(t.appConfig);if(0===e.registrationStatus){const{installationEntry:e,registrationPromise:n}=await U(t);return n||e}return e}function Y(t){return R(t,t=>{if(!t)throw p.create("installation-not-found");return Z(t)})}function Z(t){return 1===(e=t).registrationStatus&&e.registrationTime+n<Date.now()?{fid:t.fid,registrationStatus:0}:t;var e;
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */}async function tt({appConfig:t,heartbeatServiceProvider:e},n){const s=et(t,n),u=C(t,n),c=e.getImmediate({optional:!0});if(c){const t=await c.getHeartbeatsHeader();t&&u.append('x-firebase-client',t)}const f={installation:{sdkVersion:o,appId:t.appId}},p={method:'POST',headers:u,body:JSON.stringify(f)},l=await S(()=>fetch(s,p));if(l.ok){return h(await l.json())}throw await y('Generate Auth Token',l)}function et(t,{fid:e}){return`${w(t)}/${e}/authTokens:generate`}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function nt(t,e=!1){let n;const o=await R(t.appConfig,o=>{if(!ot(o))throw p.create("not-registered");const s=o.authToken;if(!e&&st(s))return o;if(1===s.requestStatus)return n=at(t,e),o;{if(!navigator.onLine)throw p.create("app-offline");const e=ct(o);return n=rt(t,e),e}});return n?await n:o.authToken}async function at(t,e){let n=await it(t.appConfig);for(;1===n.authToken.requestStatus;)await T(100),n=await it(t.appConfig);const o=n.authToken;return 0===o.requestStatus?nt(t,e):o}function it(t){return R(t,t=>{if(!ot(t))throw p.create("not-registered");const e=t.authToken;return 1===(o=e).requestStatus&&o.requestTime+n<Date.now()?Object.assign({},t,{authToken:{requestStatus:0}}):t;var o;
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */})}async function rt(t,e){try{const n=await tt(t,e),o=Object.assign({},e,{authToken:n});return await z(t.appConfig,o),n}catch(n){if(!l(n)||401!==n.customData.serverCode&&404!==n.customData.serverCode){const n=Object.assign({},e,{authToken:{requestStatus:0}});await z(t.appConfig,n)}else await J(t.appConfig);throw n}}function ot(t){return void 0!==t&&2===t.registrationStatus}function st(t){return 2===t.requestStatus&&!ut(t)}function ut(t){const e=Date.now();return e<t.creationTime||t.creationTime+t.expiresIn<e+c}function ct(t){const e={requestStatus:1,requestTime:Date.now()};return Object.assign({},t,{authToken:e})}async function ft(t){const e=t,{installationEntry:n,registrationPromise:o}=await U(e);return o?o.catch(function(){}):nt(e).catch(function(){}),n.fid}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function pt(t,e=!1){const n=t;await dt(n);return(await nt(n,e)).token}async function dt(t){const{registrationPromise:e}=await U(t);e&&await e}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function lt(t,e){const n=gt(t,e),o={method:'DELETE',headers:C(t,e)},s=await S(()=>fetch(n,o));if(!s.ok)throw await y('Delete Installation',s)}function gt(t,{fid:e}){return`${w(t)}/${e}`}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function wt(t){const{appConfig:e}=t,n=await R(e,t=>{if(!t||0!==t.registrationStatus)return t});if(n){if(1===n.registrationStatus)throw p.create("delete-pending-registration");if(2===n.registrationStatus){if(!navigator.onLine)throw p.create("app-offline");await lt(e,n),await J(e)}}}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */function mt(t,e){const{appConfig:n}=t;return D(n,e),()=>{_(n,e)}}
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */function ht(t=(0,r(d[2]).getApp)()){return(0,r(d[2])._getProvider)(t,'installations').getImmediate()}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */function yt(t){if(!t||!t.options)throw bt('App Configuration');if(!t.name)throw bt('App Name');const e=['projectId','apiKey','appId'];for(const n of e)if(!t.options[n])throw bt(n);return{appName:t.name,projectId:t.options.projectId,apiKey:t.options.apiKey,appId:t.options.appId}}function bt(t){return p.create("missing-app-config-values",{valueName:t})}
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */const Ct='installations',St=t=>{const e=t.getProvider('app').getImmediate();return{app:e,appConfig:yt(e),heartbeatServiceProvider:(0,r(d[2])._getProvider)(e,'heartbeat'),_delete:()=>Promise.resolve()}},vt=t=>{const e=t.getProvider('app').getImmediate(),n=(0,r(d[2])._getProvider)(e,Ct).getImmediate();return{getId:()=>ft(n),getToken:t=>pt(n,t)}};(0,r(d[2])._registerComponent)(new(r(d[3]).Component)(Ct,St,"PUBLIC")),(0,r(d[2])._registerComponent)(new(r(d[3]).Component)("installations-internal",vt,"PRIVATE")),(0,r(d[2]).registerVersion)(t,e),(0,r(d[2]).registerVersion)(t,e,'esm2020')},12040,[3429,3434,3432,3433]);