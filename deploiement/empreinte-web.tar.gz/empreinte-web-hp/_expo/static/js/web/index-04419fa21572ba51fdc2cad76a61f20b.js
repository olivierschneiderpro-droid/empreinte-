var _sentryDebugIds,_sentryDebugIdIdentifier;void 0===_sentryDebugIds&&(_sentryDebugIds={});try{var stack=(new Error).stack;stack&&(_sentryDebugIds[stack]="ebca2009-6cb7-42f3-95c6-02f4963f2086",_sentryDebugIdIdentifier="sentry-dbid-ebca2009-6cb7-42f3-95c6-02f4963f2086")}catch(e){}
var SENTRY_RELEASE;SENTRY_RELEASE={name: "Empreinte", version: "27.1.1"};
__d(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),Object.defineProperty(e,"getAnalytics",{enumerable:!0,get:function(){return r(d[0]).getAnalytics}}),Object.defineProperty(e,"getGoogleAnalyticsClientId",{enumerable:!0,get:function(){return r(d[0]).getGoogleAnalyticsClientId}}),Object.defineProperty(e,"initializeAnalytics",{enumerable:!0,get:function(){return r(d[0]).initializeAnalytics}}),Object.defineProperty(e,"isSupported",{enumerable:!0,get:function(){return r(d[0]).isSupported}}),Object.defineProperty(e,"logEvent",{enumerable:!0,get:function(){return r(d[0]).logEvent}}),Object.defineProperty(e,"setAnalyticsCollectionEnabled",{enumerable:!0,get:function(){return r(d[0]).setAnalyticsCollectionEnabled}}),Object.defineProperty(e,"setConsent",{enumerable:!0,get:function(){return r(d[0]).setConsent}}),Object.defineProperty(e,"setCurrentScreen",{enumerable:!0,get:function(){return r(d[0]).setCurrentScreen}}),Object.defineProperty(e,"setDefaultEventParameters",{enumerable:!0,get:function(){return r(d[0]).setDefaultEventParameters}}),Object.defineProperty(e,"setUserId",{enumerable:!0,get:function(){return r(d[0]).setUserId}}),Object.defineProperty(e,"setUserProperties",{enumerable:!0,get:function(){return r(d[0]).setUserProperties}}),Object.defineProperty(e,"settings",{enumerable:!0,get:function(){return r(d[0]).settings}})},7573,[7577]);
__d(function(g,r,i,a,m,_e,d){"use strict";Object.defineProperty(_e,'__esModule',{value:!0}),Object.defineProperty(_e,"getAnalytics",{enumerable:!0,get:function(){return Z}}),Object.defineProperty(_e,"getGoogleAnalyticsClientId",{enumerable:!0,get:function(){return ae}}),Object.defineProperty(_e,"initializeAnalytics",{enumerable:!0,get:function(){return ee}}),Object.defineProperty(_e,"isSupported",{enumerable:!0,get:function(){return te}}),Object.defineProperty(_e,"logEvent",{enumerable:!0,get:function(){return ce}}),Object.defineProperty(_e,"setAnalyticsCollectionEnabled",{enumerable:!0,get:function(){return oe}}),Object.defineProperty(_e,"setConsent",{enumerable:!0,get:function(){return le}}),Object.defineProperty(_e,"setCurrentScreen",{enumerable:!0,get:function(){return ne}}),Object.defineProperty(_e,"setDefaultEventParameters",{enumerable:!0,get:function(){return se}}),Object.defineProperty(_e,"setUserId",{enumerable:!0,get:function(){return ie}}),Object.defineProperty(_e,"setUserProperties",{enumerable:!0,get:function(){return re}}),Object.defineProperty(_e,"settings",{enumerable:!0,get:function(){return Q}});
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
       * @license
       * Copyright 2019 Google LLC
       *
       * Licensed under the Apache License, Version 2.0 (the "License");
       * you may not use this file except in compliance with the License.
       * You may obtain a copy of the License at
       *
       *   http://www.apache.org/licenses/LICENSE-2.0
       *
       * Unless required by applicable law or agreed to in writing, software
       * distributed under the License is distributed on an "AS IS" BASIS,
       * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
       * See the License for the specific language governing permissions and
       * limitations under the License.
       */
const e='analytics',t='https://www.googletagmanager.com/gtag/js',n=new(r(d[0]).Logger)('@firebase/analytics'),o={"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-initialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":'Firebase Analytics Interop Component failed to instantiate: {$reason}',"invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":'Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}',"no-api-key":"The \"apiKey\" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.","no-app-id":"The \"appId\" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.","no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":'Trusted Types detected an invalid gtag resource: {$gtagURL}.'},s=new(r(d[1]).ErrorFactory)('analytics','Analytics',o);
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
function c(e){if(!e.startsWith(t)){const t=s.create("invalid-gtag-resource",{gtagURL:e});return n.warn(t.message),''}return e}function l(e){return Promise.all(e.map(e=>e.catch(e=>e)))}function u(e,t){let n;return window.trustedTypes&&(n=window.trustedTypes.createPolicy(e,t)),n}function p(e,n){const o=u('firebase-js-sdk-policy',{createScriptURL:c}),s=document.createElement('script'),l=`${t}?l=${e}&id=${n}`;s.src=o?o?.createScriptURL(l):l,s.async=!0,document.head.appendChild(s)}function f(e){let t=[];return Array.isArray(window[e])?t=window[e]:window[e]=t,t}async function h(e,t,o,s,c,u){const p=s[c];try{if(p)await t[p];else{const e=(await l(o)).find(e=>e.measurementId===c);e&&await t[e.appId]}}catch(e){n.error(e)}e("config",c,u)}async function y(e,t,o,s,c){try{let n=[];if(c&&c.send_to){let e=c.send_to;Array.isArray(e)||(e=[e]);const s=await l(o);for(const o of e){const e=s.find(e=>e.measurementId===o),c=e&&t[e.appId];if(!c){n=[];break}n.push(c)}}0===n.length&&(n=Object.values(t)),await Promise.all(n),e("event",s,c||{})}catch(e){n.error(e)}}function w(e,t,o,s){return async function(c,...l){try{if("event"===c){const[n,s]=l;await y(e,t,o,n,s)}else if("config"===c){const[n,c]=l;await h(e,t,o,s,n,c)}else if("consent"===c){const[t,n]=l;e("consent",t,n)}else if("get"===c){const[t,n,o]=l;e("get",t,n,o)}else if("set"===c){const[t]=l;e("set",t)}else e(c,...l)}catch(e){n.error(e)}}}function b(e,t,n,o,s){let c=function(...e){window[o].push(arguments)};return window[s]&&'function'==typeof window[s]&&(c=window[s]),window[s]=w(c,e,t,n),{gtagCore:c,wrappedGtag:window[s]}}function I(e){const n=window.document.getElementsByTagName('script');for(const o of Object.values(n))if(o.src&&o.src.includes(t)&&o.src.includes(e))return o;return null}
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */const v=new class{constructor(e={},t=1e3){this.throttleMetadata=e,this.intervalMillis=t}getThrottleMetadata(e){return this.throttleMetadata[e]}setThrottleMetadata(e,t){this.throttleMetadata[e]=t}deleteThrottleMetadata(e){delete this.throttleMetadata[e]}};function P(e){return new Headers({Accept:'application/json','x-goog-api-key':e})}async function M(e){const{appId:t,apiKey:n}=e,o={method:'GET',headers:P(n)},c="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig".replace('{app-id}',t),l=await fetch(c,o);if(200!==l.status&&304!==l.status){let e='';try{const t=await l.json();t.error?.message&&(e=t.error.message)}catch(e){}throw s.create("config-fetch-failed",{httpStatus:l.status,responseMessage:e})}return l.json()}async function T(e,t=v,n){const{appId:o,apiKey:c,measurementId:l}=e.options;if(!o)throw s.create("no-app-id");if(!c){if(l)return{measurementId:l,appId:o};throw s.create("no-api-key")}const u=t.getThrottleMetadata(o)||{backoffCount:0,throttleEndTimeMillis:Date.now()},p=new F;return setTimeout(async()=>{p.abort()},void 0!==n?n:6e4),A({appId:o,apiKey:c,measurementId:l},u,p,t)}async function A(e,{throttleEndTimeMillis:t,backoffCount:o},s,c=v){const{appId:l,measurementId:u}=e;try{await D(s,t)}catch(e){if(u)return n.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${u} provided in the "measurementId" field in the local Firebase config. [${e?.message}]`),{appId:l,measurementId:u};throw e}try{const t=await M(e);return c.deleteThrottleMetadata(l),t}catch(t){const p=t;if(!j(p)){if(c.deleteThrottleMetadata(l),u)return n.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${u} provided in the "measurementId" field in the local Firebase config. [${p?.message}]`),{appId:l,measurementId:u};throw t}const f=503===Number(p?.customData?.httpStatus)?(0,r(d[1]).calculateBackoffMillis)(o,c.intervalMillis,30):(0,r(d[1]).calculateBackoffMillis)(o,c.intervalMillis),h={throttleEndTimeMillis:Date.now()+f,backoffCount:o+1};return c.setThrottleMetadata(l,h),n.debug(`Calling attemptFetch again in ${f} millis`),A(e,h,s,c)}}function D(e,t){return new Promise((n,o)=>{const c=Math.max(t-Date.now(),0),l=setTimeout(n,c);e.addEventListener(()=>{clearTimeout(l),o(s.create("fetch-throttle",{throttleEndTimeMillis:t}))})})}function j(e){if(!(e instanceof r(d[1]).FirebaseError&&e.customData))return!1;const t=Number(e.customData.httpStatus);return 429===t||500===t||503===t||504===t}class F{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */let E,$;async function x(e,t,n,o,s){if(s&&s.global)e("event",n,o);else{const s=await t;e("event",n,Object.assign({},o,{send_to:s}))}}async function C(e,t,n,o){if(o&&o.global)return e("set",{screen_name:n}),Promise.resolve();e("config",await t,{update:!0,screen_name:n})}async function O(e,t,n,o){if(o&&o.global)return e("set",{user_id:n}),Promise.resolve();e("config",await t,{update:!0,user_id:n})}async function _(e,t,n,o){if(o&&o.global){const t={};for(const e of Object.keys(n))t[`user_properties.${e}`]=n[e];return e("set",t),Promise.resolve()}e("config",await t,{update:!0,user_properties:n})}async function k(e,t){const n=await t;return new Promise((t,o)=>{e("get",n,'client_id',e=>{e||o(s.create("no-client-id")),t(e)})})}async function z(e,t){const n=await e;window[`ga-disable-${n}`]=!t}function B(e){$=e}function L(e){E=e}
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */async function S(){if(!(0,r(d[1]).isIndexedDBAvailable)())return n.warn(s.create("indexeddb-unavailable",{errorInfo:'IndexedDB is not available in this environment.'}).message),!1;try{await(0,r(d[1]).validateIndexedDBOpenable)()}catch(e){return n.warn(s.create("indexeddb-unavailable",{errorInfo:e?.toString()}).message),!1}return!0}async function U(e,t,o,s,c,l,u){const f=T(e);f.then(t=>{o[t.measurementId]=t.appId,e.options.measurementId&&t.measurementId!==e.options.measurementId&&n.warn(`The measurement ID in the local Firebase config (${e.options.measurementId}) does not match the measurement ID fetched from the server (${t.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(e=>n.error(e)),t.push(f);const h=S().then(e=>e?s.getId():void 0),[y,w]=await Promise.all([f,h]);I(l)||p(l,y.measurementId),$&&(c("consent",'default',$),B(void 0)),c('js',new Date);const b=u?.config??{};return b.origin='firebase',b.update=!0,null!=w&&(b.firebase_id=w),c("config",y.measurementId,b),E&&(c("set",E),L(void 0)),y.measurementId}
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
/**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */class N{constructor(e){this.app=e}_delete(){return delete K[this.app.options.appId],Promise.resolve()}}let K={},q=[];const R={};let G,V,W='dataLayer',H='gtag',J=!1;function Q(e){if(J)throw s.create("already-initialized");e.dataLayerName&&(W=e.dataLayerName),e.gtagName&&(H=e.gtagName)}function X(){const e=[];if((0,r(d[1]).isBrowserExtension)()&&e.push('This is a browser extension environment.'),(0,r(d[1]).areCookiesEnabled)()||e.push('Cookies are not available.'),e.length>0){const t=e.map((e,t)=>`(${t+1}) ${e}`).join(' '),o=s.create("invalid-analytics-context",{errorInfo:t});n.warn(o.message)}}function Y(e,t,o){X();const c=e.options.appId;if(!c)throw s.create("no-app-id");if(!e.options.apiKey){if(!e.options.measurementId)throw s.create("no-api-key");n.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${e.options.measurementId} provided in the "measurementId" field in the local Firebase config.`)}if(null!=K[c])throw s.create("already-exists",{id:c});if(!J){f(W);const{wrappedGtag:e,gtagCore:t}=b(K,q,R,W,H);V=e,G=t,J=!0}K[c]=U(e,q,R,t,G,W,o);return new N(e)}function Z(t=(0,r(d[2]).getApp)()){t=(0,r(d[1]).getModularInstance)(t);const n=(0,r(d[2])._getProvider)(t,e);return n.isInitialized()?n.getImmediate():ee(t)}function ee(t,n={}){const o=(0,r(d[2])._getProvider)(t,e);if(o.isInitialized()){const e=o.getImmediate();if((0,r(d[1]).deepEqual)(n,o.getOptions()))return e;throw s.create("already-initialized")}return o.initialize({options:n})}async function te(){if((0,r(d[1]).isBrowserExtension)())return!1;if(!(0,r(d[1]).areCookiesEnabled)())return!1;if(!(0,r(d[1]).isIndexedDBAvailable)())return!1;try{return await(0,r(d[1]).validateIndexedDBOpenable)()}catch(e){return!1}}function ne(e,t,o){e=(0,r(d[1]).getModularInstance)(e),C(V,K[e.app.options.appId],t,o).catch(e=>n.error(e))}async function ae(e){return e=(0,r(d[1]).getModularInstance)(e),k(V,K[e.app.options.appId])}function ie(e,t,o){e=(0,r(d[1]).getModularInstance)(e),O(V,K[e.app.options.appId],t,o).catch(e=>n.error(e))}function re(e,t,o){e=(0,r(d[1]).getModularInstance)(e),_(V,K[e.app.options.appId],t,o).catch(e=>n.error(e))}function oe(e,t){e=(0,r(d[1]).getModularInstance)(e),z(K[e.app.options.appId],t).catch(e=>n.error(e))}function se(e){V?V("set",e):L(e)}function ce(e,t,o,s){e=(0,r(d[1]).getModularInstance)(e),x(V,K[e.app.options.appId],t,o,s).catch(e=>n.error(e))}function le(e){V?V("consent",'update',e):B(e)}const de="@firebase/analytics",ue="0.10.19";(0,r(d[2])._registerComponent)(new(r(d[3]).Component)(e,(e,{options:t})=>Y(e.getProvider('app').getImmediate(),e.getProvider('installations-internal').getImmediate(),t),"PUBLIC")),(0,r(d[2])._registerComponent)(new(r(d[3]).Component)('analytics-internal',function(t){try{const n=t.getProvider(e).getImmediate();return{logEvent:(e,t,o)=>ce(n,e,t,o),setUserProperties:(e,t)=>re(n,e,t)}}catch(e){throw s.create("interop-component-reg-failed",{reason:e})}},"PRIVATE")),(0,r(d[2]).registerVersion)(de,ue),(0,r(d[2]).registerVersion)(de,ue,'esm2020')},7577,[2240,2238,2241,2242]);